import json
import os
import boto3

client = boto3.client('dynamodb')
table_name = os.environ.get('dynamodb_name')

def lambda_handler(event, context):
    
    data = client.get_item(
        TableName = table_name,
        Key = {
            'Id': {
                'N': '1'
            }
        }
    )
    
    response = {
        'statusCode': 200,
        'body': json.dumps(data),
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
        
    }
    # TODO implement
    return response