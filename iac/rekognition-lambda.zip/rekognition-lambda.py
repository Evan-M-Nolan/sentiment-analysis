import json
import boto3
import urllib.parse

def lambda_handler(event, context):
    rekognition_client = boto3.client("rekognition")
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    image_key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    response = rekognition_client.detect_faces(Image = {"S3Object": {'Bucket':bucket_name,'Name':image_key,}}, Attributes=['ALL'])

    if 'FaceDetails' not in response:
        return "No face"

    smile_confidence = response['FaceDetails'][0]['Smile']['Confidence']
    if smile_confidence < 80:
        return "Not confident enough"

    smile = response['FaceDetails'][0]['Smile']['Value']
    video_id = image_key.split("/")[1]

    dynamodb_client = boto3.client("dynamodb")
    db_item = dynamodb_client.get_item(TableName="Video", ConsistentRead=True, Key={'Id':{'S': video_id}})

    new_smile_count = 0
    new_total_count = 0

    try:
        new_smile_count = int(db_item['Item']['smileCount']['N'])
        new_total_count = int(db_item['Item']['totalCount']['N'])
    except:
        print("whoopsy")

    if smile:
        new_smile_count = new_smile_count+1
    new_smile_count = str(new_smile_count)
    new_total_count = str(new_total_count+1)

    resp = dynamodb_client.update_item(TableName="Video", Key={'Id':{'S': video_id}}, UpdateExpression="SET smileCount=:smile, totalCount=:total", ExpressionAttributeValues={':smile':{'N':new_smile_count}, ':total':{'N':new_total_count}})


    return "Thanks"