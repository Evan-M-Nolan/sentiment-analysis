import json
import os
import datetime
import boto3
from boto3.dynamodb.conditions import Key, Attr

client = boto3.resource('dynamodb')
hashtag_table = os.environ.get('dynamodb_hashtag')
video_table = os.environ.get('dynamodb_video')

def lambda_handler(event, context):
    if event['queryStringParameters'] is not None:
        search_string = event["queryStringParameters"]['search']
    else:
        search_string = ''
    default = True
    date = datetime.datetime.now() - datetime.timedelta(days=3)
    date = int(date.strftime('%s'))
    table = client.Table(hashtag_table)
    if (search_string is not None and len(search_string) > 0):
        default = False
        
    if default:
        #do the default scan
        data = table.scan(
            TableName=hashtag_table,
            FilterExpression=Attr('searchDate').gt(date)
        )

    else:
        #search for the specific hashtag
        data = table.scan(
            TableName=hashtag_table,
            FilterExpression=Attr('name').eq(search_string)
        )
    
    items = data['Items']
    v_table = client.Table(video_table)
    startDate = items[0]['searchDate'] if len(items) > 0 else 0
    endDate = items[0]['searchDate'] if len(items) > 0 else 0
    totalCount = 0
    smileCount = 0
    for item in items:
        item['searchDate'] = int(item['searchDate'])
        if (int(item['searchDate']) > endDate):
            endDate = int(item['endDate'])
        
        if (int(item['searchDate']) < startDate):
            startDate = int(item['searchDate'])
        
        videoIds = item['videoIds']
        for id in videoIds:
            video_item = v_table.get_item(
                Key={'Id': id}
            )
            video = video_item['Item']
            totalCount += video['totalCount']
            smileCount += video['smileCount']

    results: any = {}
    results['startDate'] = datetime.datetime.fromtimestamp(startDate).strftime('%m/%d/%Y')
    results['endDate'] = datetime.datetime.fromtimestamp(endDate).strftime('%m/%d/%Y')
    results['smilePercent'] = round(float(smileCount/totalCount),2) if totalCount > 0 else 0
    print(type(results['smilePercent']))
    response = {
        'statusCode': 200,
        'body': json.dumps(results),
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
        
    }
    return response