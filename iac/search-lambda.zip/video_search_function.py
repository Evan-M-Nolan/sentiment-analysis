import json
import requests
import boto3
import os
import random

api_key = "AIzaSyAIA9xNDBHj-BU_0TNCY7LbYlE3o_7_ovI"
client = boto3.client('sqs')
queue_url = os.environ.get('sqs_url')
def lambda_handler(event, context):
    if event['queryStringParameters'] is not None:

        dynamo_list = []
        query = event['queryStringParameters']['topic']
        url = "https://youtube.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q=shorts%20" + query + "&type=video&videoDuration=short&key=" +api_key
        res = requests.get(url)

        json_resp = res.json()
        for item in json_resp["items"]:
            video_id = (item["id"]["videoId"])
            message = {
                "topic": query,
                "videoId": video_id
            }
            dynamo_list.append(video_id)
            succ = client.send_message(
                QueueUrl=queue_url,
                MessageBody=json.dumps(message))
        dynamodb_client = boto3.client("dynamodb")
        dynamodb_client.put_item(TableName="Hashtag", Item = {'Id':{'S':str(random.getrandbits(128))}, 'name':{'S':query}, 'videoIDs':{'SS':dynamo_list}, 'searchDate':{'N':'1668723403'} })
        response = {
            'statusCode': 200,
            'body': json.dumps(succ),
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        
        }
        
        return response
