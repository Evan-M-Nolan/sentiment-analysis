import json
import requests
import boto3
import os

api_key = "AIzaSyCywDFrDBrachFLhmO2rUgXGpk6XRCp0fE"
client = boto3.client('sqs')
queue_url = os.environ.get('queue_url')
def lambda_handler(event, context):
    if event['queryStringParameters'] is not None:
        query = event['queryStringParameters']['topic']
        url = "https://youtube.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q=shorts%20" + query + "&type=video&videoDuration=short&key=" +api_key
        res = requests.get(url)

        json_resp = res.json()
        for item in json_resp["items"]:
            video_id = (item["id"]["videoId"])
            message = {
                "topic": query,
                "videoId": video_id
            }
            client.send_message(
                QueueUrl=queue_url,
                MessageBody=json.dumps(message))
        return 
