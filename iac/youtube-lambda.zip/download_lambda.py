import boto3
from pytube import YouTube
import json
import os

s3_client = boto3.client('s3')
bucket = os.environ.get('raw-data-bucket')

def lambda_handler(event, context):
    bucket = 'raw-data-bucket-514-team666'
    message = event['Records'][0]['body']
    if message is not None:
        message = json.loads(message)
        key = message["topic"]
        videoId = message['videoId']
        url = YouTube('https://www.youtube.com/watch?v='+videoId)
        video = url.streams.get_highest_resolution()
        path_to_download_folder = "/tmp/"
        file = video.download(path_to_download_folder, filename=videoId+".mp4")
        key+="/"+videoId+".mp4"
        resp = s3_client.upload_file(file, bucket, key)
        return json.dumps(resp)
      
       