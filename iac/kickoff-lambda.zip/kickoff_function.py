import json
import boto3

client = boto3.client('lambda')

def lambda_handler(event, context):
    Topics = [
          "Ukraine",
          "Apple",
          "Tesla",
          "News",
          "Human",
          "Microsoft",
          "Viral",
          "Election",
          "Technology",
          "Love"
      	]
    for topic in Topics:
        message = {
            "queryStringParameters": 
            {
            "topic": topic
            }
        }
        client.invoke(
            FunctionName="search-youtube-for-ids",
            InvocationType='Event',
            Payload=json.dumps(message)
            )
      	
    return {
        'statusCode': 200,
        'body': json.dumps('Dumped the 10 topics')
    }
